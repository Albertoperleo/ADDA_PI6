package ejercicio3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.jgrapht.GraphPath;

import ejercicio3.DatosE3.Componente;
import ejercicio3.DatosE3.Producto;
import ejercicio3.GvE3.E3Edge;
import ejercicio3.GvE3.E3Vertex;

public class SolucionE3 {

	private Map<Producto, Integer> map = new HashMap<Producto, Integer>();
	private static Integer t_prod = DatosE3.t_prod;
	private static Integer t_elab = DatosE3.t_elab;
	private static List<Componente> componentes = DatosE3.componentes;
	private static List<Producto> productos = DatosE3.productos;
	
	public static SolucionE3 of(GraphPath<E3Vertex, E3Edge> path) {
		List<Integer> la = path.getEdgeList().stream()
		.map(x -> x.action())
		.toList();
		return new SolucionE3(la);
	}
	
	public SolucionE3(List<Integer> valores) {
		IntStream.range(0, valores.size())
		.forEach(i -> {
			if(valores.get(i)!=0) {
				map.put(productos.get(i), valores.get(i));
			}
		});
	}
	
	//FORMATO
	public static final String FORMATO = "DATOS ENTRADA:\n"
			+ "Componentes: %s -> %s\n"
			+ "Productos: %s -> %s\n"
			+ "Tiempo de producci�n m�x: %s\n"
			+ "Tiempo de elaboraci�n m�x: %s\n\n"
			+ "ALGORITMO A*\n%s\n\n"
			+ "ALGORITMO BT\n%s\n\n"
			+ "ALGORITMO PD\n%s\n\n";
	
	//IMPRIMIR
	public static void impresion(Integer i, String aX, String bT, String pD) throws FileNotFoundException {
		PrintStream imp = new PrintStream(new File("./soluciones/E3/sol"+i+".txt"));
		imp.print(String.format(FORMATO, 
				componentes.size(), componentes,
				productos.size(), productos,
				t_prod, t_elab,
				aX, bT, pD));
		imp.close();
	}
	
	@Override
	public String toString() {
		return "Precio total: " + map.entrySet().stream()
				.mapToDouble(x -> x.getKey().precio()*x.getValue()).sum()
				+ "Productos seleccionados:" + map.entrySet().stream()
				.map(x -> String.format("%s: %s unidades", x.getKey().id(), x.getValue()))
				.collect(Collectors.joining("\n")) + "\n\n";
	}
}
