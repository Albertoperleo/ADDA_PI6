package ejercicio3;

import java.util.function.Predicate;

import ejercicio3.GvE3.E3Vertex;

public class HeuristicaE3 {

	public static Double heuristica(E3Vertex v1,
			Predicate<E3Vertex> goal, E3Vertex v2) {
		return heuristica(v1, DatosE3.productos.size());
	}
	
	public static Double heuristica(E3Vertex v, Integer n) {
		Double valor = 0.;
//		for(int i=v.id(); i<n; i++) {
//			valor = valor + DatosE2.candidatos.get(i).valor();
//		}
		return valor;
	}
}
