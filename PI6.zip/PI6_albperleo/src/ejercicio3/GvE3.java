package ejercicio3;

import java.util.List;
import java.util.function.Predicate;

import ejercicio3.DatosE3.Componente;
import ejercicio3.DatosE3.Producto;
import us.lsi.common.List2;
import us.lsi.graphs.virtual.SimpleEdgeAction;
import us.lsi.graphs.virtual.VirtualVertex;

public class GvE3 {

	//VÉRTICE
	public record E3Vertex(Integer id, Integer tProdRestante, Integer tElabRestante) 
		implements VirtualVertex<E3Vertex, E3Edge, Integer>{
		
		//VBLES DE DATOS
		public static List<Componente> componentes;
		public static Integer nC;
		public static List<Producto> productos;
		public static Integer nP;
		public static Integer tProd;
		public static Integer tElab;
		
		public static void poblar() {
			componentes = List2.copy(DatosE3.componentes);
			nC = componentes.size();
			productos = List2.copy(DatosE3.productos);
			nP = componentes.size();
			tProd = DatosE3.t_prod;
			tElab = DatosE3.t_elab;
		}
		
		//MÉTODOS
		public static E3Vertex of(Integer id, Integer tProdRestante, Integer tElabRestante) {
			return new E3Vertex(id, tProdRestante, tElabRestante);
		}
		
		//PROPIEDADES DE LOS VÉRTICES
		public static E3Vertex initialVertex() {
			return of(0, tProd, tElab);
		}
		
		public static Predicate<E3Vertex> goal(){
			return v -> v.id() == nP;
		}
		
		@Override
		public List<Integer> actions(){
			if(this.id < nP) {
				List<Integer> tiempos = calcTiempoTotal(this.id);
				Integer tProd = tiempos.get(0);
				Integer tElab = tiempos.get(1);
				Integer r = 0;
				
				if(productos.get(this.id).udMax() < this.tProdRestante/tProd
						&& productos.get(this.id).udMax() < this.tElabRestante/tElab) {
					r = productos.get(this.id).udMax();
				} else {
					if(this.tProdRestante/tProd < this.tElabRestante/tElab) {
						r = this.tProdRestante/tProd;
					} else {
						r = this.tElabRestante/tElab;
					}
				}
				
				return List2.rangeList(0, r);
				
			} else {
				return List.of(0);
			}
		}
		
		public static List<Integer> calcTiempoTotal(Integer id) {
			List<String> compKey = productos.get(id)
					.componentes().keySet().stream().toList();
			List<Componente> compProd = componentes.stream()
			.filter(x -> compKey.contains(x.id()))
			.toList();
			
			Integer tProd = compProd.stream()
			.mapToInt(x -> x.tProd()*productos.get(id).componentes().get(x.id()))
			.sum();
			
			Integer tElab = compProd.stream()
					.mapToInt(x -> x.tElab()*productos.get(id).componentes().get(x.id()))
					.sum();
			
			return List.of(tProd, tElab);
		}
		
		@Override
		public E3Vertex neighbor(Integer a) {
			if(a == 0) {
				return of(this.id+1, this.tProdRestante, this.tElabRestante);
			} else {
				List<Integer> tiempos = calcTiempoTotal(this.id);
				Integer tProd = this.tProdRestante - tiempos.get(0);
				Integer tElab = this.tElabRestante - tiempos.get(1);
				return of(this.id, tProd, tElab);
			}
		}

		@Override
		public E3Edge edge(Integer a) {
			E3Vertex v = this.neighbor(a);
			return E3Edge.of(this,v,a);
		}
	}
	
	//ARISTA
	public record E3Edge(E3Vertex source, E3Vertex target, Integer action, Double weight)
		implements SimpleEdgeAction<E3Vertex, Integer> {
		public static E3Edge of(E3Vertex v1, E3Vertex v2, Integer a) {
			Double w = a*1.0*DatosE3.productos.get(v1.id).precio();
			return new E3Edge(v1,v2,a,w);
		}
	}
}
