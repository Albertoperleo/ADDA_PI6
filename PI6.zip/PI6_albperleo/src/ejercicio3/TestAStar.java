package ejercicio3;

import java.util.function.Predicate;
import java.util.stream.IntStream;

import org.jgrapht.GraphPath;
import org.jgrapht.graph.SimpleDirectedGraph;

import ejercicio3.DatosE3;
import ejercicio3.HeuristicaE3;
import ejercicio3.SolucionE3;
import ejercicio3.GvE3.E3Edge;
import ejercicio3.GvE3.E3Vertex;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.alg.AStar;
import us.lsi.graphs.alg.AStar.AStarType;
import us.lsi.graphs.virtual.EGraph;
import us.lsi.graphs.virtual.SimpleVirtualGraph;

public class TestAStar {

	public static void test() {
		IntStream.range(1, 3).boxed()
		.forEach(x -> {
			DatosE3.iniDatos("./datos/PI6Ej2DatosEntrada"+x+".txt");
			System.out.println("Resultado para test "+x+":");
			
			//V�rtices clave
			E3Vertex.poblar();
			E3Vertex start = E3Vertex.initialVertex();
			Predicate<E3Vertex> goal = E3Vertex.goal();
			
			//Grafo
			EGraph<E3Vertex, E3Edge> graph = 
					SimpleVirtualGraph.sum(start, goal, e -> e.weight());
			
			System.out.println("### Algoritmo A* ###");
			AStar<E3Vertex, E3Edge> ms = 
					AStar.of(graph, HeuristicaE3::heuristica, AStarType.Max);
			
			GraphPath<E3Vertex, E3Edge> path = ms.search().get();
			SolucionE3 s = SolucionE3.of(path);
			System.out.println(s);
			
			SimpleDirectedGraph<E3Vertex, E3Edge> r = ms.graph();
			
			GraphColors.toDot(r,"./soluciones/E3/A*sol"+x+".gv",
					v->String.format("((%s,%s)",v.id()),
					e->e.action().toString(),
					v->GraphColors.colorIf(Color.red,path.getVertexList().contains(v)),
					e->GraphColors.colorIf(Color.red,path.getEdgeList().contains(e)));
			
			DatosE3.limpiar();
			
		});
	}
	
	public static void main(String[] args) {
		test();
	}
}
