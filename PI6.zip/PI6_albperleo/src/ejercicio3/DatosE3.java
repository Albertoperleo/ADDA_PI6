package ejercicio3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import us.lsi.common.Files2;

public class DatosE3 {

	//OBJETOS DEL EJERCICIO
	public record Componente(String id, Integer tProd, Integer tElab) {
		public static Componente of(String cadena) {
			String[] trozos = cadena.split(";");
			String id = trozos[0].split(":")[0].trim();
			Integer prod = Integer.valueOf(trozos[0].split(": prod=")[1]);
			Integer elab = Integer.valueOf(trozos[1].split("elab=")[1].trim());
			return new Componente(id, prod, elab);
		}
		@Override
		public String toString() {
			return id;
		}
	}
	public record Producto(String id, Double precio, Map<String, Integer> componentes, Integer udMax) {
		public static Producto of(String cadena) {
			String[] trozos1 = cadena.split("->");
			String[] trozos2 = trozos1[1].split(";");
			String id = trozos1[0].trim();
			Double precio = Double.valueOf(trozos2[0].split("precio=")[1].trim());
			Integer udMax = Integer.valueOf(trozos2[2].split("max_u=")[1].trim());
			Map<String, Integer> compNecesarios = new HashMap<>();
			List<String> cs = List.of(trozos2[1].split("comp=")[1].split(","));
			for(String s : cs) {
				compNecesarios.put(s.split(":")[0].replace("(", ""), 
						Integer.valueOf(s.split(":")[1].replace(")", "")));
			}
			return new Producto(id, precio, compNecesarios, udMax);
		}
		@Override
		public String toString() {
			return id;
		}
	}
	
	//VBLES PARA DATOS
	public static Integer t_prod;
	public static Integer t_elab;
	public static List<Componente> componentes = new ArrayList<Componente>();
	public static List<Producto> productos = new ArrayList<Producto>();
	
	//CARGAR DATOS
	public static void iniDatos(String ruta) {
		Files2.streamFromFile(ruta)
		.forEach(x -> {
			if(x.startsWith("T_prod")) {
				t_prod = Integer.valueOf(x.split("=")[1].trim());
			}else if(x.startsWith("T_manual")) {
				t_elab = Integer.valueOf(x.split("=")[1].trim());
			}else if(x.startsWith("C")) {
				componentes.add(Componente.of(x));
			}else if(x.startsWith("P")) {
				productos.add(Producto.of(x));
			}
		});
	}
	
	//REESTABLECER VBLES
	public static void limpiar() {
		componentes.clear();
		productos.clear();
		t_prod = 0;
		t_elab = 0;
	}	
}
