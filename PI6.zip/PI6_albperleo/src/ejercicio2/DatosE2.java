package ejercicio2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import us.lsi.common.Files2;

public class DatosE2 {

	public record Candidato(String id, Set<String> cualidades, Double sueldo, Integer valor, List<String> incompatible) {
		public static Candidato of(String cadena) {
			String[] parse = cadena.split(";");
			String id = parse[0].split(":")[0];
			Set<String> cualidades = new HashSet<>();
			String[] a = parse[0].split(":")[1].trim().split(",");
			for(int i=0; i<a.length; i++) {
				cualidades.add(a[i]);
			}
			Double sueldo = Double.valueOf(parse[1].trim());
			Integer valor = Integer.valueOf(parse[2].trim());
			List<String> incomp = List.of(parse[3].trim().split(","));
			return new Candidato(id, cualidades, sueldo, valor, incomp);
		}
		@Override
		public String toString() {
			return String.format("%s: %s; %s; %s; %s", id, cualidades, sueldo, valor, incompatible);
		}
	}
	public record Empresa(Double presupuesto, Set<String> cualidades) {
		public static Empresa of(List<String> cadenas) {
			Double presupuesto = Double.valueOf(cadenas.get(1).split(":")[1].trim());
			Set<String> cualidades = Set.of(cadenas.get(0).split(":")[1].trim().split(","));
			return new Empresa(presupuesto, cualidades);
		}
		@Override
		public String toString() {
			return String.format("Se busca %s y contamos con %s$", cualidades, presupuesto);
		}
	}
	
	//VBLES PARA DATOS
	public static List<Candidato> candidatos = new ArrayList<Candidato>();
	public static Empresa empresa;
	
	//CARGAR DATOS
	public static void iniDatos(String ruta) {
		List<String> datos = Files2.linesFromFile(ruta);
		List<String> dEmpresa = datos.subList(0, 2);
		List<String> dCandidatos = datos.subList(2, datos.size());
		
		empresa = Empresa.of(dEmpresa);
		
		dCandidatos.stream()
		.map(x -> Candidato.of(x))
		.forEach(c -> candidatos.add(c));
	}
	
	//REESTABLECEMOS VBLES
	public static void limpiar() {
		candidatos.clear();
	}
	
	public static void main(String[] args) {
		iniDatos("./datos/PI6Ej1DatosEntrada3.txt");
		System.out.println(empresa);
		System.out.println(candidatos);
	}
}
