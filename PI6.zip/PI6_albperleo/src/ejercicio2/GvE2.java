package ejercicio2;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import ejercicio2.DatosE2.Candidato;
import ejercicio2.DatosE2.Empresa;
import us.lsi.common.List2;
import us.lsi.common.Set2;
import us.lsi.common.String2;
import us.lsi.graphs.virtual.SimpleEdgeAction;
import us.lsi.graphs.virtual.VirtualVertex;

public class GvE2 {

	//V�RTICE
	public record E2Vertex(Integer id, List<Integer> candidatosTomados, 
			Set<String> cualidadesRestantes, Double sueldoRestante) 
	implements VirtualVertex<E2Vertex, E2Edge, Integer>{
		
		//VBLES DE DATOS
		public static List<Candidato> candidatos;
		public static Integer n;
		public static Empresa empresa;
		public static Set<String> cualidades;
		
		public static void poblar() {
			candidatos = List2.copy(DatosE2.candidatos);
			n = DatosE2.candidatos.size();
			empresa = DatosE2.empresa;
			cualidades = Set2.copy(DatosE2.empresa.cualidades());
		}
		
		//M�TODOS
		public static E2Vertex of(Integer id, List<Integer> candidatosTomados,
				Set<String> cualidadesRestantes, Double sueldoRestante) {
			return new E2Vertex(id, candidatosTomados, cualidadesRestantes, sueldoRestante);
		}
		
		//PROPIEDADES DE LOS V�RTICES
		public static E2Vertex initialVertex() {
			return of(0, List2.empty(), cualidades, empresa.presupuesto());
		}
		public static Predicate<E2Vertex> goal(){
			return v -> v.id() == n-1;
		}
	
		@Override
		public List<Integer> actions() {
			/*
			 * Vamos a tener dos posibles acciones...
			 * 	 0: no se selecciona al candidato
			 * 	 1: se selecciona al candidato
			 * 
			 * Para decidir la acción contaremos con dos
			 * predicados...
			 */
			Set<String> noSeleccionar = this.candidatosTomados.stream()
					.map(x -> candidatos.get(x).incompatible())
					.flatMap(x -> x.stream())
					.collect(Collectors.toSet());
			
			System.out.println("Candidato:"+ this.id);
			System.out.println("candidatos tomados:"+this.candidatosTomados);
			System.out.println("noSeleccionar:"+noSeleccionar);
			
			Predicate<Integer> a = i -> noSeleccionar.contains(candidatos.get(i).id());
			Predicate<Integer> b = i -> this.sueldoRestante >= candidatos.get(i).sueldo();
			
			System.out.println(candidatos.get(this.id).id()+" in "+noSeleccionar+"? --> "+a.test(this.id));
			System.out.println(this.sueldoRestante +">="+ candidatos.get(this.id).sueldo() + "? -->" + b.test(this.id));
			
			
			List<Integer> acciones = new ArrayList<>();
			acciones.add(0);
			if(this.id < n && !a.test(this.id) && b.test(this.id)) {
				acciones.add(1);
			}
	
			System.out.println(acciones);
			System.out.println(String2.linea());
			
			return acciones;
		}
		@Override
		public E2Vertex neighbor(Integer a) {
			/*
			 * Si la acción es...
			 * 	 0: no se selecciona al candidato, por tanto,
			 * 	 unicamente se incrementará el índice del vértice
			 * 
			 * 	 1: se selecciona al candidato, por tanto, habrá
			 * 	 que actualizar el índice, la lista de candidatos tomados,
			 * 	 cualidades restantes y el presupuesto restante de la empresa.
			 */
			List<Integer> cT = List2.copy(this.candidatosTomados);
			Set<String> cR = Set.copyOf(this.cualidadesRestantes);
			Double sR = this.sueldoRestante;
			
			if(a>0) {
				cT.add(this.id);
				cR = cR.stream()
				.filter(x -> !candidatos.get(this.id).cualidades().contains(x))
				.collect(Collectors.toSet());
				sR = sR - candidatos.get(this.id).sueldo();
			}
			
			return of(this.id+1, cT, cR, sR);
		}
		@Override
		public E2Edge edge(Integer a) {
			E2Vertex v = this.neighbor(a);
			return E2Edge.of(this,v,a);
		}
	}
	
	//ARISTA
	public record E2Edge(E2Vertex source, E2Vertex target, Integer action, Double weight)
	implements SimpleEdgeAction<E2Vertex, Integer> {
		public static E2Edge of(E2Vertex v1, E2Vertex v2, Integer a) {
			Double w = a*DatosE2.candidatos.get(v1.id()).valor()*1.0;
			return new E2Edge(v1,v2,a,w);
		}
	}
}
