package ejercicio2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.jgrapht.GraphPath;

import ejercicio2.DatosE2.Candidato;
import ejercicio2.DatosE2.Empresa;
import ejercicio2.GvE2.E2Edge;
import ejercicio2.GvE2.E2Vertex;

public class SolucionE2 {

	private List<Candidato> sol = new ArrayList<Candidato>();
	private static Empresa empresa = DatosE2.empresa;
	private static List<Candidato> candidatos = DatosE2.candidatos;
	
	public static SolucionE2 of(GraphPath<E2Vertex, E2Edge> path) {
		List<Integer> la = path.getEdgeList().stream()
				.map(x -> x.action())
				.toList();
		return new SolucionE2(la);
	}
	
	public SolucionE2(List<Integer> valores) {
		IntStream.range(0, valores.size())
		.forEach(i -> {
			if(valores.get(i) == 1) {
				sol.add(candidatos.get(i));
			}
		});
	}
	
	//FORMATO
	public static final String FORMATO = "DATOS ENTRADA:\n"
			+ "Candidatos: %s -> %s\n"
			+ "Empresa -> %s\n\n"
			+ "ALGORITMO A*\n%s\n\n"
			+ "ALGORITMO BT\n%s\n\n"
			+ "ALGORITMO PD\n%s\n\n";
	
	//IMPRIMIR ARCHIVO
	public static void impresion(Integer i, String aX, String bT, String pD) throws FileNotFoundException {
		PrintStream imp = new PrintStream(new File("./soluciones/E2/sol"+i+".txt"));
		imp.print(String.format(FORMATO, 
				candidatos.size(), candidatos,
				empresa,
				aX, bT, pD));
		imp.close();
	}
	
	@Override
	public String toString() {
		return "Candidatos seleccionados:\n"
				+ sol.stream()
				.map(x -> x.toString())
				.collect(Collectors.joining("\n"))
				+ "\nSueldos totales: " + sol.stream()
				.mapToDouble(x -> x.sueldo()).sum()
				+ "\nValores totales: " + sol.stream()
				.mapToInt(x -> x.valor()).sum();
	}
}
