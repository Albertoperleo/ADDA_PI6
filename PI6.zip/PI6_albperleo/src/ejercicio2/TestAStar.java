package ejercicio2;

import java.util.function.Predicate;
import java.util.stream.IntStream;

import org.jgrapht.GraphPath;
import org.jgrapht.graph.SimpleDirectedGraph;

import ejercicio2.GvE2.E2Edge;
import ejercicio2.GvE2.E2Vertex;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.alg.AStar;
import us.lsi.graphs.alg.AStar.AStarType;
import us.lsi.graphs.virtual.EGraph;
import us.lsi.graphs.virtual.SimpleVirtualGraph;

public class TestAStar {

	public static void main(String[] args) {
		IntStream.range(1, 3).boxed()
		.forEach(x -> {
			DatosE2.iniDatos("./datos/PI6Ej2DatosEntrada"+x+".txt");
			System.out.println("Resultado para test "+x+":");
			
			//V�rtices clave
			E2Vertex.poblar();
			E2Vertex start = E2Vertex.initialVertex();
			Predicate<E2Vertex> goal = E2Vertex.goal();
			
			//Grafo
			EGraph<E2Vertex, E2Edge> graph = 
					SimpleVirtualGraph.sum(start, goal, e -> e.weight());
			
			System.out.println("### Algoritmo A* ###");
			AStar<E2Vertex, E2Edge> ms = 
					AStar.of(graph, HeuristicaE2::heuristica, AStarType.Max);
			
			GraphPath<E2Vertex, E2Edge> path = ms.search().get();
			SolucionE2 s = SolucionE2.of(path);
			System.out.println(s);
			
			SimpleDirectedGraph<E2Vertex, E2Edge> r = ms.graph();
			
			GraphColors.toDot(r,"./soluciones/E2/A*sol"+x+".gv",
					v->String.format("((%s,%s)",v.id(),v.sueldoRestante()),
					e->e.action().toString(),
					v->GraphColors.colorIf(Color.red,path.getVertexList().contains(v)),
					e->GraphColors.colorIf(Color.red,path.getEdgeList().contains(e)));
			
			DatosE2.limpiar();
			
		});
	}
}
