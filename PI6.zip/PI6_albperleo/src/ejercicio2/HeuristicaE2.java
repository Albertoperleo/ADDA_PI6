package ejercicio2;

import java.util.function.Predicate;
import java.util.stream.IntStream;

import ejercicio2.GvE2.E2Vertex;

public class HeuristicaE2 {
	
	public static Double heuristica(E2Vertex v1,
			Predicate<E2Vertex> goal, E2Vertex v2) {
		return heuristica(v1, DatosE2.candidatos.size());
	}
	
	public static Double heuristica(E2Vertex v, Integer n) {
		Double valor = 0.;
//		for(int i=v.id(); i<n; i++) {
//			valor = valor + DatosE2.candidatos.get(i).valor();
//		}
		return valor;
	}
}
