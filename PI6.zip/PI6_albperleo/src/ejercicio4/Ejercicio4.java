package ejercicio4;

import java.util.ArrayList;
import java.util.List;

import us.lsi.common.Files2;


public class Ejercicio4 {

	//OBJETOS MODELO
	public record Contenedor(String id, Integer capacidad, String tipo) {
		public static Contenedor of(String datos) {
			String[] trozos1 = datos.split(":");
			String[] trozos2 = trozos1[1].split(";");
			String id = trozos1[0].trim();
			Integer capacidad = Integer.valueOf(trozos2[0].split("=")[1]);
			String tipo = trozos2[1].split("=")[1].trim();
			return new Contenedor(id, capacidad, tipo);
		}
		@Override
		public String toString() {
			return String.format("[%s: %s; %s]", id, capacidad, tipo);
		}
	}
	public record Elemento(String id, Integer tam, List<String> tipos) {
		public static Elemento of(String datos) {
			String[] trozos1 = datos.split(":");
			String[] trozos2 = trozos1[1].split(";");
			String id = trozos1[0].trim();
			Integer tam = Integer.valueOf(trozos2[0].trim());
			List<String> tipos = List.of(trozos2[1].trim().split(","));
			return new Elemento(id, tam, tipos);
		}
		@Override
		public String toString() {
			return String.format("(%s: %s; %s)", id, tam);
		}
	}
	
	//VBLES PARA DATOS
	public static List<Contenedor> contenedores = new ArrayList<Contenedor>();
	public static List<Elemento> elementos = new ArrayList<Elemento>();
	
	//CARGAR DATOS
	public static void iniDatos(String ruta) {
		Files2.streamFromFile(ruta)
		.filter(x -> x.startsWith("C"))
		.forEach(x -> contenedores.add(Contenedor.of(x)));
		Files2.streamFromFile(ruta)
		.filter(x -> x.startsWith("E"))
		.forEach(x -> elementos.add(Elemento.of(x)));
	}
	
	//REESTABLECER VBLES
	public static void limpiar() {
		contenedores.clear();
		elementos.clear();
	}
}
