package ejercicio4;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import ejercicio4.Ejercicio4.Contenedor;
import ejercicio4.Ejercicio4.Elemento;
import us.lsi.common.List2;

public class SolucionE4 {

	private Map<Contenedor, List<Elemento>> map = new HashMap<Contenedor, List<Elemento>>();
	private static List<Contenedor> contenedores = Ejercicio4.contenedores;
	private static List<Elemento> elementos = Ejercicio4.elementos;
	
	public SolucionE4(List<Integer> valores) {
		IntStream.range(0, valores.size())
		.forEach(x -> {
			if(valores.get(x) < contenedores.size()) {
				Contenedor c = contenedores.get(valores.get(x));
				Elemento e = elementos.get(x);
				if(map.containsKey(c)) {
					List<Elemento> elements = List2.copy(map.get(c));
					elements.add(e);
					map.put(c, elements);
				}else {
					map.put(c, List.of(e));
				}
			}
		});
	}
	
	//FORMATO
	public static final String FORMATO = "DATOS ENTRADA:\n"
			+ "Contenedores: %s -> %s\n"
			+ "Elementos: %s -> %s\n\n"
			+ "ALGORITMO A*\n%s\n\n"
			+ "ALGORITMO BT\n%s\n\n"
			+ "ALGORITMO PD\n%s\n\n";
	
	//IMPRIMIR
	public static void impresion(Integer i, String aX, String bT, String pD) throws FileNotFoundException {
		PrintStream imp = new PrintStream(new File("./soluciones/E4/sol"+i+".txt"));
		imp.print(String.format(FORMATO, 
				contenedores.size(), contenedores,
				elementos.size(), elementos,
				aX, bT, pD));
		imp.close();
	}
	
	@Override
	public String toString() {
		return "Reparto obtenido:\n"
				+ map.entrySet().stream()
				.map(x -> String.format("%s -> %s", x.getKey().toString(), x.getValue().toString()))
				.collect(Collectors.joining("\n")) + "\n\n";
	}	
}
