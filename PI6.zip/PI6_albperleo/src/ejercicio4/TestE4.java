package ejercicio4;

public class TestE4 {

	public static void test() {
		
	}
}
