package ejercicio1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.jgrapht.GraphPath;

import ejercicio1.DatosE1.Archivo;
import ejercicio1.DatosE1.Memoria;
import ejercicio1.GvE1.E1Edge;
import ejercicio1.GvE1.E1Vertex;
import us.lsi.common.List2;
import us.lsi.common.String2;

public class SolucionE1 {

	private Map<String,List<Archivo>> map = new HashMap<String,List<Archivo>>();
	private static List<Memoria> memorias = DatosE1.memorias;
	private static List<Archivo> archivos = DatosE1.archivos;
	
	public static SolucionE1 of(GraphPath<E1Vertex,E1Edge> path) {
		List<Integer> la = path.getEdgeList().stream()
				.map(e -> e.action())
				.toList();
		return new SolucionE1(la);
	}
	
	public SolucionE1(List<Integer> valores) {
		IntStream.range(0, valores.size())
		.forEach(i -> {
			String m = valores.get(i)==0 ? "No almacenado" : memorias.get(valores.get(i)-1).id();
			Archivo a = archivos.get(i);
			if(map.containsKey(m)) {
				List<Archivo> aux = List2.copy(map.get(m));
				aux.add(a);
				map.put(m, aux);
			} else {
				map.put(m, List.of(a));
			}
		});
	}
	
	//FORMATO
	public static final String FORMATO = "DATOS ENTRADA:\n"
			+ "Archivos: %s -> %s\n"
			+ "Memorias: %s -> %s\n\n"
			+ "ALGORITMO A*\n%s"
			+ "ALGORITMO BT\n%s"
			+ "ALGORITMO PD\n%s";
	
	//IMPRESI�N EN ARCHIVO
	public static void impresion(Integer i, String aX, String bT, String pD) throws FileNotFoundException {
		PrintStream imp = new PrintStream(new File("./soluciones/E1/sol"+i+".txt"));
		imp.print(String.format(FORMATO, 
				archivos.size(), archivos,
				memorias.size(), memorias,
				aX, bT, pD));
		imp.close();
	}
	
	@Override
	public String toString() {
		return map.entrySet().stream()
				.map(x -> String.format("%s -> %s", x.getKey(), x.getValue()))
				.collect(Collectors.joining("\n")) + "\n" + String2.linea();
	}
}
