package ejercicio1;

import java.util.Locale;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.graph.SimpleDirectedGraph;

import ejercicio1.GvE1.E1Edge;
import ejercicio1.GvE1.E1Vertex;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.alg.BackTracking;
import us.lsi.graphs.alg.BackTracking.BTType;
import us.lsi.graphs.alg.DynamicProgramming.PDType;
import us.lsi.graphs.alg.DynamicProgrammingReduction;
import us.lsi.graphs.virtual.EGraph;
import us.lsi.graphs.virtual.SimpleVirtualGraph;

public class TestPD {

	public static void test() {
		Locale.setDefault(new Locale("en", "US"));
		IntStream.range(1, 3)
		.forEach(i -> {
			DatosE1.iniDatos("./datos/PI6Ej1DatosEntrada"+i+".txt");
			System.out.println("\nResultados test "+i+":\n");
			
			E1Vertex.poblar();
			E1Vertex start = E1Vertex.initialVertex();
			Predicate<E1Vertex> goal = E1Vertex.goal();
			
			//Grafo
			EGraph<E1Vertex, E1Edge> graph = 
					SimpleVirtualGraph.sum(start, goal, e -> e.weight());
			
			System.out.println("### Programación Dinámica ###");
			DynamicProgrammingReduction<E1Vertex, E1Edge> pd =
					DynamicProgrammingReduction.of(graph,
							HeuristicaE1::heuristica,
							PDType.Max);
			
			Optional<GraphPath<E1Vertex,E1Edge>> sp = pd.search();
			GraphPath<E1Vertex,E1Edge> path = sp.get();
			SolucionE1 s = SolucionE1.of(path);
			Long total =  path.getEdgeList().stream()
					.map(e -> e.action())
					.filter(e -> e!=0)
					.count();
			System.out.println("Total archivos guardados: " + total);
			System.out.println(s);
			
//			Graph<E1Vertex, E1Edge> r = pd.outGraph;
//			GraphColors.toDot(r,"./soluciones/E1/PDsol"+i+".gv",
//					v->String.format("((%s,%s)",v.id(),v.capRestante()),
//					e->e.action().toString(),
//					v->GraphColors.colorIf(Color.red,path.getVertexList().contains(v)),
//					e->GraphColors.colorIf(Color.red,path.getEdgeList().contains(e))
//					);
			
			DatosE1.limpiar();
		});
	}
	
	public static void main(String[] args) {
		test();
	}
}
