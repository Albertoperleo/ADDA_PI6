package ejercicio1;

import java.util.Locale;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import org.jgrapht.graph.SimpleDirectedGraph;

import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.alg.BackTracking;
import us.lsi.graphs.alg.BackTracking.BTType;
import us.lsi.graphs.virtual.EGraph;
import us.lsi.graphs.virtual.SimpleVirtualGraph;
import ejercicio1.GvE1.E1Edge;
import ejercicio1.GvE1.E1Vertex;

public class TestBT {
	
	public static void test() {
		//Set up
		Locale.setDefault(new Locale("en", "US"));

		IntStream.range(1, 3).boxed()
		.forEach(i -> {
			DatosE1.iniDatos("./datos/PI6Ej1DatosEntrada"+i+".txt");
			System.out.println("\nResultados test "+i+":\n");

			E1Vertex.poblar();
			E1Vertex start = E1Vertex.initialVertex();
			Predicate<E1Vertex> goal = E1Vertex.goal();

			//Grafo
			EGraph<E1Vertex, E1Edge> graph = 
					SimpleVirtualGraph.sum(start, goal, e -> e.weight());

			System.out.println("### BackTracking ###");
			BackTracking<E1Vertex, E1Edge, SolucionE1> bta =
					BackTracking.of(graph,
							HeuristicaE1::heuristica,
							SolucionE1::of,
							BTType.Max);

			bta.search();
			if(bta.getSolution().isPresent()) {
				Long total =  bta.optimalPath.getEdgeList().stream()
						.map(e -> e.action())
						.filter(e -> e!=0)
						.count();
				System.out.println("Total archivos guardados: " + total);
				System.out.println(bta.getSolution().get());

//				SimpleDirectedGraph<E1Vertex, E1Edge> r = bta.graph();
//				GraphColors.toDot(r,"./soluciones/E1/BTsol"+i+".gv",
//						v->String.format("((%s,%s)",v.id(),v.capRestante()),
//						e->e.action().toString(),
//						v->GraphColors.colorIf(Color.red,bta.optimalPath.getVertexList().contains(v)),
//						e->GraphColors.colorIf(Color.red,bta.optimalPath.getEdgeList().contains(e))
//						);
				DatosE1.limpiar();
			} else {
				System.out.println("No existe soluciÓn!!");
			}
		});
	}

	public static void main(String[] args) {
		test();
	}
}
