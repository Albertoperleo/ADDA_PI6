package ejercicio1;

import java.util.function.Predicate;
import java.util.stream.IntStream;

import org.jgrapht.GraphPath;
import org.jgrapht.graph.SimpleDirectedGraph;

import ejercicio1.GvE1.E1Vertex;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.alg.AStar;
import us.lsi.graphs.alg.AStar.AStarType;
import us.lsi.graphs.virtual.EGraph;
import us.lsi.graphs.virtual.SimpleVirtualGraph;
import ejercicio1.GvE1.E1Edge;

public class TestAStar {

	public static void test() {
		IntStream.range(1, 3).boxed()
		.forEach(x -> {
			DatosE1.iniDatos("./datos/PI6Ej1DatosEntrada"+x+".txt");
			System.out.println("\nResultado para test "+x+":");
			
			//V�rtices clave
			E1Vertex.poblar();
			E1Vertex start = E1Vertex.initialVertex();
			Predicate<E1Vertex> goal = E1Vertex.goal();
			
			//Grafo
			EGraph<E1Vertex, E1Edge> graph = 
					SimpleVirtualGraph.sum(start, goal, e -> e.weight());
			
			System.out.println("### Algoritmo A* ###");
			AStar<E1Vertex, E1Edge> ms = 
					AStar.of(graph, HeuristicaE1::heuristica, AStarType.Max);
			
			GraphPath<E1Vertex, E1Edge> path = ms.search().get();
			SolucionE1 s = SolucionE1.of(path);
			Long total =  path.getEdgeList().stream()
					.map(e -> e.action())
					.filter(e -> e!=0)
					.count();
			System.out.println("Total archivos guardados: " + total);
			System.out.println(s);
			
			
			SimpleDirectedGraph<E1Vertex, E1Edge> r = ms.graph();
			
			GraphColors.toDot(r,"./soluciones/E1/A*sol"+x+".gv",
					v->String.format("((%s,%s)",v.id(),v.capRestante()),
					e->e.action().toString(),
					v->GraphColors.colorIf(Color.red,path.getVertexList().contains(v)),
					e->GraphColors.colorIf(Color.red,path.getEdgeList().contains(e))
					);
			DatosE1.limpiar();
		});
	}
	
	public static void main(String[] args) {
		test();
	}
}
