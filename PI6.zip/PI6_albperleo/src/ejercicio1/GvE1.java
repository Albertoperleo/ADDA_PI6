package ejercicio1;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.IntStream;

import ejercicio1.DatosE1.Archivo;
import ejercicio1.DatosE1.Memoria;
import us.lsi.common.List2;
import us.lsi.graphs.virtual.SimpleEdgeAction;
import us.lsi.graphs.virtual.VirtualVertex;


public class GvE1 {

	//V�RTICE
	public record E1Vertex(Integer id, List<Integer> capRestante) 
		implements VirtualVertex<E1Vertex, E1Edge, Integer> {
		
		//VBLES DE DATOS
		public static List<Archivo> archivos;
		public static List<Memoria> memorias;
		public static Integer n;
		public static Integer m;
		public static List<Integer> capacidadInicial;
		
		public static void poblar() {
			archivos = List2.copy(DatosE1.archivos);
			memorias = List2.copy(DatosE1.memorias);
			n = DatosE1.archivos.size();
			m = DatosE1.memorias.size();
			capacidadInicial = DatosE1.memorias.stream()
					.map(x -> x.capacidad()).toList();
		}

		//M�TODOS
		public static E1Vertex of(Integer id, List<Integer> capRestante) {
			return new E1Vertex(id, capRestante);
		}
		public static E1Vertex copy(E1Vertex v) {
			return new E1Vertex(v.id, v.capRestante);
		}
		
		//PROPIEDADES DE LOS V�RTICES
		public static E1Vertex initialVertex() {
			return of(0, List2.copy(capacidadInicial));
		}
		public static E1Vertex lastVertex() {
			return of(n-1, IntStream.range(0, m).boxed().map(x -> x*0).toList());
		}
		public static Predicate<E1Vertex> goal(){
			return  v -> v.id() == n-1; //---------> PREGUNTAR: ERROR EN A* PERO EN BT Y PD NO
		}
		
		@Override
		public List<Integer> actions() {
			/*
			 * Vamos a tomar los siguientes valores como acciones:
			 * 	 0: no guardamos el fichero
			 * 	 x(!=0): guardamos el fichero en la memoria x
			 * 
			 * Para saber si guardaremos o no el archivo nos guiaremos por
			 * los predicados a y b:
			 * 	 a: se respeta el tamaño máx. por archivo en memoria
			 * 	 b: el archivo cabe dentro de la memoria
			 */
			List<Integer> acciones = new ArrayList<>();
			
			Predicate<Integer> a = i -> memorias.get(i).tamArchivo() >= archivos.get(this.id).peso();
			Predicate<Integer> b = i -> this.capRestante.get(i) >= archivos.get(this.id).peso();
			IntStream.range(-1, m)
			.filter(i -> i+1==0?true:false || a.test(i) && b.test(i))
			.boxed()
			.map(x -> x+1)
			.forEach(x -> acciones.add(x));
			return acciones;
		}
		
		@Override
		public E1Vertex neighbor(Integer a) {
			/*
			 * Si la accion es...
			 * 	 0: no hemos guardado el archivo, por tanto no se ve
			 * 	 afectada ninguna memoria.
			 * 	 x!=0: hemos guardado el archivo en la memoria x, tendremos
			 * 	 que modificar la capacidad restante de dicha memoria.
			 * 
			 * Arreglar: no coge el último archivo, se lo salta...
			 */
			List<Integer> nuevasCap = List2.copy(this.capRestante);
			
			if(a>0) {
				Integer cap = this.capRestante.get(a-1) - 
						archivos.get(this.id).peso();
				nuevasCap.set(a-1, cap);
			}
			return of(this.id+1, nuevasCap);			
		}
		
		@Override
		public E1Edge edge(Integer a) {
			E1Vertex v = this.neighbor(a);
			return E1Edge.of(this,v,a);
		}

	}
	
	//ARISTA
	public record E1Edge(E1Vertex source, E1Vertex target, Integer action, Double weight) 
	implements SimpleEdgeAction<E1Vertex, Integer> {
		public static E1Edge of(E1Vertex v1, E1Vertex v2, Integer a) {
			return new E1Edge(v1,v2,a,a*1.0);
		}
	}
}
