package ejercicio1;

import java.util.function.Predicate;

import ejercicio1.GvE1.E1Vertex;

public class HeuristicaE1 {

	public static Double heuristica(E1Vertex v1,
			Predicate<E1Vertex> goal,
			E1Vertex v2) {
		return heuristica(v1, DatosE1.archivos.size());
	}
	
	/*
	 * Para que funcione la heur�stica tenemos que haber ordenado
	 * previamente la lista de archivos de mayor a menor tama�o.
	 * 
	 * �Cu�ntos ficheros en rango [i,n) se podr�an incluir como mucho?
	 */
	public static Double heuristica(E1Vertex v, Integer n) {
		if(v.id() == n) {
			return n*1.0;
		} else {
			return n - v.id()*1.0;
		}
	}
}
