package ejercicio1;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import us.lsi.common.Files2;

public class DatosE1 {
	
	//OBJETOS MODELADOS
	public record Archivo(String id, Integer peso) {
		public static Archivo of(String cadena) {
			String id = cadena.split(":")[0];
			Integer peso = Integer.valueOf(cadena.split(":")[1].trim());
			return new Archivo(id, peso);
		}
		@Override
		public String toString() {
			return id;
		}
	}
	public record Memoria(String id, Integer capacidad, Integer tamArchivo) {
		public static Memoria of(String cadena) {
			String id = cadena.split(":")[0];
			Integer capacidad = Integer.valueOf(cadena.split(";")[0].split("=")[1].trim());
			Integer tamArchivo = Integer.valueOf(cadena.split(";")[1].split("=")[1].trim());
			return new Memoria(id, capacidad, tamArchivo);
		}
		@Override
		public String toString() {
			return id;
		}
	}
	
	//VBLES PARA GUARDAR DATOS
	public static List<Archivo> archivos = new ArrayList<Archivo>();
	public static List<Memoria> memorias = new ArrayList<Memoria>();
	
	//CARGAR DATOS
	public static void iniDatos(String ruta) {
		Files2.streamFromFile(ruta)
		.filter(x -> x.startsWith("M"))
		.map(x -> Memoria.of(x))
		.forEach(x -> memorias.add(x));
		
		Files2.streamFromFile(ruta)
		.filter(x -> x.startsWith("F"))
		.map(x -> Archivo.of(x))
		//ordenamos los archivos de mayor a menor tama�o
		.sorted(Comparator.comparing(Archivo::peso).reversed())
		.forEach(x -> archivos.add(x));
	}
	
	//REESTABLECER AL INICIO
	public static void limpiar() {
		memorias.clear();
		archivos.clear();
	}
	
}
