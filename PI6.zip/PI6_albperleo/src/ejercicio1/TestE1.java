package ejercicio1;

public class TestE1 {
	
	public static void main(String[] args) {
		TestAStar.test();
		TestBT.test();
		TestPD.test();
	}
}
